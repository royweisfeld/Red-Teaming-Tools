Python library to parse Windows minidump file format


