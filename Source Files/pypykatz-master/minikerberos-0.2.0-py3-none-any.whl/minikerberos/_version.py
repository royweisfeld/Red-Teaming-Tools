
__version__ = "0.2.0"
__banner__ = \
"""
# minikerberos %s 
# Author: Tamas Jos @skelsec (skelsecprojects@gmail.com)
""" % __version__