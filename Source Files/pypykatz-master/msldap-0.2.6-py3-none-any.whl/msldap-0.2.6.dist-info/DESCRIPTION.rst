Python library to play with MS LDAP


