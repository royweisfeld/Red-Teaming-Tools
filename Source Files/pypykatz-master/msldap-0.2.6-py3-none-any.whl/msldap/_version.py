
__version__ = "0.2.6"
__banner__ = \
"""
# msldap %s 
# Author: Tamas Jos @skelsec (skelsecprojects@gmail.com)
""" % __version__