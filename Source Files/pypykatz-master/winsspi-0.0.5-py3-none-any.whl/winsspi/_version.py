__version__ = "0.0.5"
__banner__ = \
"""
# winsspi %s 
# Author: Tamas Jos @skelsec (skelsecprojects@gmail.com)
""" % __version__